import { Component } from '@angular/core';

@Component({
  selector: 'app-audit-reporting',
  imports: [],
  templateUrl: './audit-reporting.html',
  styleUrl: './audit-reporting.scss'
})
export class AuditReportingComponent {

}
