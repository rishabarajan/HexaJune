package com.hexaware.assetmanagement.exception;


public class InternalServerErrorException extends RuntimeException {

	public InternalServerErrorException(String error) {
		super(error);
	}
}
