package com.hexaware.assetmanagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssetManagementSystemmApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssetManagementSystemmApplication.class, args);
	}

}
